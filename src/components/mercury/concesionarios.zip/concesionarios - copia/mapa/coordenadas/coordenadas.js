const coordinates = [
		{
			lat: -40.055453999763984,
			lng: -66.523111284521,
			name: 'Venice',
		},
		{
			lat: 41.9102415,
			lng: 12.3959151,
			name: 'Rome',
		},
		{
			lat: 45.4628328,
			lng: 9.1076927,
			name: 'Milan',
		},

]


export default coordinates